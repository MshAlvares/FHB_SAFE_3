# FHB SAFE 3 — application Android (version de départ)

Application Android native en Kotlin + Jetpack Compose pour saisir des statistiques de match et obtenir une première estimation indicative pour le basket-ball, le football et le hockey.

## Ce que contient cette version
- Choix du sport.
- Saisie des noms d'équipes et de moyennes de production/points ou buts concédés.
- Prise en compte d'un bonus domicile.
- Calcul d'estimations indicatives de production, total et probabilités simplifiées.
- Interface en français, thème sombre et avertissement sur les limites du modèle.

## Limites importantes
Cette version est un **prototype de départ**. Elle n'interroge pas encore de fournisseur de données sportives, ne vérifie pas les blessures ou les compositions et n'utilise pas de modèle calibré sur un historique réel. Les probabilités sont pédagogiques et ne doivent pas être considérées comme des prédictions fiables pour miser de l'argent. Le paramètre « prudente » modifie la sensibilité de la formule, mais ne rend pas le résultat garanti.

## Ouvrir dans Android Studio
1. Installe Android Studio sur un ordinateur.
2. Décompresse le projet.
3. Dans Android Studio, choisis **Open** et sélectionne le dossier `FHB_SAFE_3_Android`.
4. Laisse Gradle se synchroniser.
5. Lance l'application sur un émulateur ou un téléphone Android avec le débogage USB activé.

## Créer un dépôt GitHub
1. Connecte-toi à GitHub et crée un nouveau dépôt nommé `FHB-SAFE-3-Android`.
2. Décompresse ce ZIP.
3. Depuis le terminal, dans le dossier du projet, exécute :

```bash
git init
git add .
git commit -m "Initial commit - FHB SAFE 3 Android"
git branch -M main
git remote add origin https://github.com/TON-PSEUDO/FHB-SAFE-3-Android.git
git push -u origin main
```

Remplace `TON-PSEUDO` par ton nom d'utilisateur GitHub.

## Générer un APK
Dans Android Studio : **Build > Build Bundle(s) / APK(s) > Build APK(s)**. L'APK de débogage est généralement créé sous `app/build/outputs/apk/debug/`.

## Architecture prévue pour les prochaines versions
- `data/`: connexion à une API de résultats et calendriers.
- `domain/`: modèles Elo, Poisson/Skellam, Monte-Carlo, valeur espérée.
- `history/`: sauvegarde locale des analyses.
- `validation/`: calibration, suivi des erreurs et backtests.

## Sécurité des clés API
Ne mets jamais de clé API privée directement dans le code Android ou dans GitHub. Utilise un serveur intermédiaire ou des secrets de déploiement.
