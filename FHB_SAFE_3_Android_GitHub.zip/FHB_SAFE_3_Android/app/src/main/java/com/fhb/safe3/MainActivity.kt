package com.fhb.safe3

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FhbSafeApp() }
    }
}

private enum class Sport(val label: String, val unit: String) {
    BASKET("Basket-ball", "points"),
    FOOT("Football", "buts"),
    HOCKEY("Hockey", "buts")
}

private data class Forecast(
    val homeExpected: Double,
    val awayExpected: Double,
    val homeWin: Double,
    val draw: Double,
    val awayWin: Double,
    val total: Double,
    val difference: Double,
    val note: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FhbSafeApp() {
    var sport by remember { mutableStateOf(Sport.BASKET) }
    var home by remember { mutableStateOf("Équipe domicile") }
    var away by remember { mutableStateOf("Équipe extérieure") }
    var homeAttack by remember { mutableStateOf("84") }
    var awayAttack by remember { mutableStateOf("79") }
    var homeDefense by remember { mutableStateOf("78") }
    var awayDefense by remember { mutableStateOf("82") }
    var homeAdvantage by remember { mutableStateOf("3") }
    var confidence by remember { mutableStateOf("prudente") }
    var result by remember { mutableStateOf<Forecast?>(null) }
    var expanded by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("FHB SAFE 3", fontWeight = FontWeight.Bold)
                            Text("Laboratoire de prédiction sportive", style = MaterialTheme.typography.labelSmall)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier.padding(padding).fillMaxSize()
                    .verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("1. Sport à analyser", style = MaterialTheme.typography.titleMedium)
                        ExposedDropdownMenuBox(
                            expanded = expanded,
                            onExpandedChange = { expanded = !expanded }
                        ) {
                            OutlinedTextField(
                                value = sport.label, onValueChange = {}, readOnly = true,
                                label = { Text("Discipline") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                                modifier = Modifier.menuAnchor().fillMaxWidth()
                            )
                            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                Sport.entries.forEach { item ->
                                    DropdownMenuItem(
                                        text = { Text(item.label) },
                                        onClick = { sport = item; result = null; expanded = false }
                                    )
                                }
                            }
                        }
                        Text(
                            when (sport) {
                                Sport.BASKET -> "Modèle simplifié : attaque, défense et avantage du terrain."
                                Sport.FOOT -> "Modèle simplifié de buts attendus, inspiré d'une approche Poisson."
                                Sport.HOCKEY -> "Modèle simplifié de buts attendus. Les gardiens et compositions restent à vérifier."
                            },
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("2. Informations du match", style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(home, { home = it }, label = { Text("Équipe à domicile") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(away, { away = it }, label = { Text("Équipe à l'extérieur") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Text("Moyennes récentes par match", style = MaterialTheme.typography.labelLarge)
                        NumberField("Production domicile (${sport.unit})", homeAttack, { homeAttack = it })
                        NumberField("Production extérieure (${sport.unit})", awayAttack, { awayAttack = it })
                        NumberField("Indice défensif domicile (même unité)", homeDefense, { homeDefense = it })
                        NumberField("Indice défensif extérieur (même unité)", awayDefense, { awayDefense = it })
                        NumberField("Bonus domicile (points/buts)", homeAdvantage, { homeAdvantage = it })
                        Text(
                            "Saisis des moyennes comparables sur une période similaire. Pour les indices défensifs, utilise les points/buts concédés par match : plus bas = meilleure défense.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("3. Niveau de prudence", style = MaterialTheme.typography.titleMedium)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = confidence == "prudente", onClick = { confidence = "prudente" })
                            Text("Prudente")
                            Spacer(Modifier.width(12.dp))
                            RadioButton(selected = confidence == "standard", onClick = { confidence = "standard" })
                            Text("Standard")
                        }
                        Button(
                            onClick = {
                                result = calculateForecast(
                                    sport,
                                    homeAttack.toDoubleOrNull() ?: 0.0,
                                    awayAttack.toDoubleOrNull() ?: 0.0,
                                    homeDefense.toDoubleOrNull() ?: 0.0,
                                    awayDefense.toDoubleOrNull() ?: 0.0,
                                    homeAdvantage.toDoubleOrNull() ?: 0.0,
                                    confidence
                                )
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Calculer l'analyse") }
                    }
                }

                result?.let { forecast ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Résultats indicatifs", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("${home.ifBlank { "Domicile" }} : ${fmt(forecast.homeExpected)} ${sport.unit}")
                            Text("${away.ifBlank { "Extérieur" }} : ${fmt(forecast.awayExpected)} ${sport.unit}")
                            HorizontalDivider()
                            Text("Victoire domicile : ${pct(forecast.homeWin)}")
                            if (sport == Sport.FOOT) Text("Match nul : ${pct(forecast.draw)}")
                            Text("Victoire extérieur : ${pct(forecast.awayWin)}")
                            Text("Total attendu : ${fmt(forecast.total)} ${sport.unit}")
                            Text("Écart attendu domicile : ${if (forecast.difference >= 0) "+" else ""}${fmt(forecast.difference)}")
                            HorizontalDivider()
                            Text("Lecture SAFE : ${forecast.note}", fontWeight = FontWeight.SemiBold)
                            Text(
                                "Ces chiffres sont calculés à partir des valeurs saisies. Ce n'est pas un modèle entraîné sur des données en direct et ce n'est pas une garantie de résultat.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }

                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Prochaines briques à développer", style = MaterialTheme.typography.titleMedium)
                        Text("• Import automatique des calendriers et résultats")
                        Text("• Blessures, compositions et forme domicile/extérieur")
                        Text("• Modèles Elo, Poisson/Skellam et simulations Monte-Carlo")
                        Text("• Comparaison des cotes et calcul de valeur espérée")
                        Text("• Historique des prédictions, calibration et backtests")
                    }
                }
                Text(
                    "Responsabilité : l'application aide à analyser des données, mais ne garantit aucun gain. N'engage jamais de l'argent que tu ne peux pas perdre.",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun NumberField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { input -> if (input.matches(Regex("^\\d{0,4}(\\.\\d{0,2})?$"))) onValueChange(input) },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

private fun calculateForecast(
    sport: Sport, ha: Double, aa: Double, hd: Double, ad: Double, homeBonus: Double, confidence: String
): Forecast {
    val scale = if (sport == Sport.BASKET) 1.0 else 0.08
    val expectedHome = max(0.05, (ha + ad) / 2.0 + homeBonus * scale)
    val expectedAway = max(0.05, (aa + hd) / 2.0)
    val diff = expectedHome - expectedAway
    val sensitivity = if (confidence == "prudente") 0.045 else 0.065
    val homeRaw = 1.0 / (1.0 + exp(-diff * sensitivity))
    val draw = if (sport == Sport.FOOT) {
        // Approximation pédagogique : le nul est plus probable lorsque les forces sont proches.
        0.28 * exp(-kotlin.math.abs(diff) * 0.35)
    } else 0.0
    val remaining = 1.0 - draw
    val homeProb = (homeRaw * remaining).coerceIn(0.01, remaining - 0.01)
    val awayProb = remaining - homeProb
    val note = when {
        kotlin.math.abs(diff) < if (sport == Sport.BASKET) 4.0 else 0.35 ->
            "écart estimé faible : éviter un handicap agressif ou s'abstenir."
        diff > 0 -> "avantage théorique domicile, à confirmer avec les données récentes et les cotes."
        else -> "avantage théorique extérieur : vérifier le contexte avant toute sélection."
    }
    return Forecast(expectedHome, expectedAway, homeProb, draw, awayProb, expectedHome + expectedAway, diff, note)
}

private fun fmt(value: Double) = String.format(java.util.Locale.FRANCE, "%.1f", value)
private fun pct(value: Double) = "${(value * 100).toInt()} %"
